package tf_idf;


import org.apache.hadoop.mapreduce.Job;  
import org.apache.hadoop.io.*;        
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;
import java.io.IOException;

//Written by Gregory ISLAS
// Defines the mapper class for the third and final round of the tf-idf calculations
//map method will read in lines from round two of the map reduce chain, then 
//output as key, value pairs word, doc_id#wordcount#doc_wordcount
public class MapTFIDF extends Mapper<LongWritable, Text, Text, Text> {

//defintion of the map function
@Override
protected void map(LongWritable key, Text value, Context context) throws IOException,InterruptedException
    
{
 String[] line = value.toString().split("\\s+");
 String word = line[0]; //word should be first element in line
 context.write(new Text(word), new Text(line[1] + "#" + line[2]));	// key = word, value = doc_id#wordcount#docwordcount
        
    }
}






