package tf_idf;

import org.apache.hadoop.mapreduce.Job;  
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Reducer;
import java.io.IOException;
import java.util.LinkedList;

//Written by Gregory ISLAS
// Definition of the reduce class for the final round of the map reduce tf-idf
//chain. Only outputs the top 20 (in descending order) tf-idf word/document pairs

public class ReduceTFIDF extends Reducer<Text, Text, Text, DoubleWritable> {
    private final static int NUM_DOCS = 2; // change this if number of docs change
	
	private double[] top_20_vals = new double[20]; //keep track of top 20 tf-idf scores
	private String[] top_20_keys = new String[20]; //keep track of top 20 tf-idf keys
    // Definition of the reduce function
    @Override
    protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException,InterruptedException
    {
        
    	LinkedList<String> vals2 = new LinkedList<String>(); //keeps track of the number of documents that the word is in
        float docs_word_in = 0;
        for (Text val: values) {
        // System.out.println(key.toString());
         //System.out.println(val.toString());
           docs_word_in++;
           vals2.add(val.toString()); //doc_id - assumes a list of document_ids will be able to fit in main memory
        }

        for (int i = 0; i < vals2.size(); i++) { //loop through the document ids, and compute the tf-idf for each word/doc_id pair
        	String tempvals[] = vals2.get(i).split("#");
        	String docid = tempvals[0]; //doc_id should be first field in string
        	float wc = Float.parseFloat(tempvals[1]); //get the wordcount
        	float wpd = Float.parseFloat(tempvals[2]); // get the number of words in the document
        	double tfidf = (wc/wpd)*Math.log(NUM_DOCS/docs_word_in); //calculate tf_idf score
        	//context.write(new Text(key.toString() + "\t" + docid), new DoubleWritable(tfidf)); //uncomment out this line, and commment out next section if want all tf-idf scores 
        	if(Double.compare(tfidf, top_20_vals[0]) > 0) { //add to list in correct position if one of top 20 seen so far
        		int index = 1;
        		while(index < top_20_vals.length && Double.compare(tfidf, top_20_vals[index]) > 0) {
        			top_20_vals[index-1] = top_20_vals[index];
        			top_20_keys[index-1] = top_20_keys[index];
        			index++;
        		}
        		index--;
        		top_20_vals[index] = tfidf;
        		top_20_keys[index] = key.toString() + "#" + docid;

        	}
        	
        }

    }
    
    //Definition of the cleanup method - just writes to context the sorted top 20 tf-idf scores
    @Override
	protected void cleanup(Context context) throws IOException,
    InterruptedException{ 
    	for(int i = top_20_keys.length-1; i > -1; i-- ) {
    		context.write(new Text(top_20_keys[i]), new DoubleWritable(top_20_vals[i]));
    	}
    }

}

