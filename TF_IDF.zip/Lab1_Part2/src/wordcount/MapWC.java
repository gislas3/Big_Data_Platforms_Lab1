package wordcount;


import org.apache.hadoop.mapreduce.Job;  
import org.apache.hadoop.io.*;        
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;
import java.io.IOException;
//Written by Gregory ISLAS
// Mapper takes reads in lines from the two text files callwild.txt and robinson_crusoe.txt
// and writes key, value pairs of the form word	doc_id, 1 for each word in the two files
public class MapWC extends Mapper<LongWritable, Text, Text, IntWritable> {

	private final static IntWritable ONE =  new IntWritable(1); //will be written out each time map method is called

	//definition of the map function
@Override
protected void map(LongWritable key, Text value, Context context) throws IOException,InterruptedException
    
{
	String filename = ((FileSplit) context.getInputSplit()).getPath().getName(); //get the file name, or "doc_id" for the current line
	for (String token: value.toString().split("\\s+|--")) { // split the line at spaces or double hyphens
		token = token.toLowerCase(); //change to all lower case - assume that capitalization doesn't affect the definition of a word
        int end_index = token.length(); //keep track of the end index
        int i = 0; //start index
		while(i < end_index) { //loop through string and remove punctuation unless there is a hyphen or apostrophe in the middle of the string o
        	//
        	Character c = token.charAt(i);
        	
        	if(!Character.isLetterOrDigit(c)) { // not a letter or number
        		if(i == 0) { //first character in string - always remove
        			token = token.substring(1, token.length());
        			i--;
        		}
        		else if (i == token.length() -1 ){ //last character in string  - always remove
        			token = token.substring(0, token.length()-1);
        		}
        		else { //in middle of string
        			if(c != '-' && c != '\'') { //remove unless the character is a hyphen or apostrophe
        				token = token.substring(0, i) + token.substring(i+1, token.length());
        				i--;
        			}	
        		}
        		
        	}
        	i++;
        	end_index = token.length();
        }
		
		if(!token.isEmpty()) { //check to make sure word isn't empty
			context.write(new Text(token + "\t" + filename), ONE); //write the key, value pairs of (word	doc_id, 1) to the context
			
		}
	}
	
        
    }
}






