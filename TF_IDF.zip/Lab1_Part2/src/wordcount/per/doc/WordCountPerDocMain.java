package wordcount.per.doc;

import org.apache.hadoop.conf.Configuration;

import org.apache.hadoop.conf.Configured;

import org.apache.hadoop.fs.FileSystem;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;

import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;

import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;

import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

import org.apache.hadoop.util.GenericOptionsParser;

import org.apache.hadoop.util.Tool;

import org.apache.hadoop.util.ToolRunner;

//Written by Gregory ISLAS
//Defines the main class for the map reduce job word count per document, i.e how many words each document has
public class WordCountPerDocMain extends Configured implements Tool {


	//definition of the run method
    public int run(String[] args) throws Exception {
        if (args.length != 2) { //simple check for correct input
            System.out.println("Usage: [input] [output]");
            System.exit(-1);
        }

        // Creation of the job and titled with a brief description of the task
        Job job = Job.getInstance(getConf());
        job.setJobName("Word Count for Round Two of Tf-Idf");
        job.setJarByClass(WordCountPerDocMain.class);
        // Set the Mapper,  and Reducer Classes
        job.setJarByClass(WordCountPerDocMain.class);
        job.setMapperClass(MapWCPD.class);
        job.setReducerClass(ReduceWCPD.class);
        
        
        
        //set number of reducers
        job.setNumReduceTasks(1); //since only two documents, just use one reducer; if there were many more documents, should probably increase this
        // Definition of the types of the input/output keys
        job.setMapOutputKeyClass(Text.class); //key will be doc_id
        job.setMapOutputValueClass(Text.class); //value will be word concatenated with its count for the mapper
        job.setOutputKeyClass(Text.class); //final output key will be word + doc_id

        job.setOutputValueClass(Text.class); //final output value will be the count of the word and the total number of words in the document  

        //Definition of the input and output paths
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));
        Path outputFilePath = new Path(args[1]);
        //Delete the output directory if it already exists
        FileSystem fs = FileSystem.newInstance(getConf());

        if (fs.exists(outputFilePath)) {
            fs.delete(outputFilePath, true);
        }
        
        return job.waitForCompletion(true) ? 0: 1;
    }


    public static void main(String[] args) throws Exception {
        WordCountPerDocMain wc = new WordCountPerDocMain(); // initialize the job
        int res = ToolRunner.run(wc, args);
        System.exit(res); //exit with what run method returned 
    }

}

