package wordcount.per.doc;

import org.apache.hadoop.mapreduce.Job;  
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Reducer;
import java.io.IOException;
import java.util.LinkedList;

//Written by Gregory ISLAS
// Definition of the reduce class - takes in key, value pairs of the form doc_id, wordcount#word
// and outputs key, value pairs of the form word	doc_id, wordcount#words per doc

public class ReduceWCPD extends Reducer<Text, Text, Text, Text> {
    
	// Definition of the reduce function
    @Override
    protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException,InterruptedException
    {
    	LinkedList<String> words = new LinkedList<String>(); //stores the words to write out
        LinkedList<String> counts = new LinkedList<String>(); // stores the counts of each word, i.e. counts[i] = count(words[i])
       
        int doc_wc = 0; //keep track of the word count of the document
        for (Text val: values) {
           String newval[] = val.toString().split("#"); //split the value on '#'

           doc_wc += Integer.parseInt(newval[1]);  //second portion will be the count of the word in the document
           words.add(newval[0]); //add the word for later writing to context
           counts.add(newval[1]); // add the count for later writing to context
        }
  
        for (int i = 0; i < words.size(); i++) { //write word, doc_id, and wordcount#doc_word_count to context
        	context.write(new Text(words.get(i) + "\t" + key.toString()), new Text(counts.get(i) + "#" + doc_wc));
        }

    }

}

