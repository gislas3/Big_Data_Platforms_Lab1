package wordcount.per.doc;


import org.apache.hadoop.mapreduce.Job;  
import org.apache.hadoop.io.*;        
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;
import java.io.IOException;

//Written by Gregory ISLAS
// Definition of the map class - takes in as input the results of the wordcount job,
// and writes as key, value pairs doc_id, word#wordcount
public class MapWCPD extends Mapper<LongWritable, Text, Text, Text> {
// Definition of the map function

@Override
protected void map(LongWritable key, Text value, Context context) throws IOException,InterruptedException
    
{
 String[] line = value.toString().split("\\s+"); //split on white spaces
 String docid = line[1]; //document_id should be second element
 context.write(new Text(docid), new Text(line[0] + "#" + line[2])); //write the key, value pairs
        
    }
}






