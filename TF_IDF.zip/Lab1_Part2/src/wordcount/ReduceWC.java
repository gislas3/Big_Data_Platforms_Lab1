package wordcount;

import org.apache.hadoop.mapreduce.Job;  
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Reducer;
import java.io.IOException;


// Defines the reduce class, which computes an aggregation of sum
//Written by Gregory ISLAS
public class ReduceWC extends Reducer<Text, IntWritable, Text, IntWritable> {
    
	// Definition of the reduce method - will sum up all values in values, then write the result
	// (without changing the key) to the context
    @Override
    protected void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException,InterruptedException
    {
        
        int wc = 0;
        for (IntWritable val: values) { //iterate through values and sum them
           wc += val.get();
        }
        context.write(key, new IntWritable(wc)); //write to the context

    }

}

