package wordcount;

import org.apache.hadoop.conf.Configuration;

import org.apache.hadoop.conf.Configured;

import org.apache.hadoop.fs.FileSystem;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;

import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;

import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;

import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

import org.apache.hadoop.util.GenericOptionsParser;

import org.apache.hadoop.util.Tool;

import org.apache.hadoop.util.ToolRunner;

//Written by Gregory ISLAS
//defines the main class for running the mapreduce job that will return a word count by
//file for each word in the files
public class WordCountMain extends Configured implements Tool {


    public int run(String[] args) throws Exception {
        if (args.length != 2) { // simple check for correct input
            System.out.println("Usage: [input] [output]");
            System.exit(-1);
        }

        // Creation of the job and titled with a brief description of the task
        Job job = Job.getInstance(getConf());
        job.setJobName("Word Count for Round One of Tf-Idf");
        job.setJarByClass(WordCountMain.class);
        // Set the Mapper, Combiner, and Reducer Classes
        job.setJarByClass(WordCountMain.class);
        job.setMapperClass(MapWC.class);
        job.setCombinerClass(ReduceWC.class); // Combiner same as reducer - just summing values of counts
        job.setReducerClass(ReduceWC.class);
        
        
        
        //set number of reducers
        job.setNumReduceTasks(5); 
        // Definition of the types of the input/output keys
        job.setMapOutputKeyClass(Text.class); //key will be word + doc_id
        job.setMapOutputValueClass(IntWritable.class); //value will be 1 (for mapper)
        job.setOutputKeyClass(Text.class); //final output key will be word + doc_id

        job.setOutputValueClass(IntWritable.class); //final output value will be the count

        //Definition of the input and output paths
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));
        Path outputFilePath = new Path(args[1]);
        //Delete the output directory if it already exists
        FileSystem fs = FileSystem.newInstance(getConf());

        if (fs.exists(outputFilePath)) {
            fs.delete(outputFilePath, true);
        }
        
        return job.waitForCompletion(true) ? 0: 1;
    }


    public static void main(String[] args) throws Exception {
        WordCountMain wc = new WordCountMain(); // initialize the job
        int res = ToolRunner.run(wc, args);
        System.exit(res); //exit with what run method returned 
    }

}

