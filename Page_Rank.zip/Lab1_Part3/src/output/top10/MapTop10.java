package output.top10;

import org.apache.hadoop.mapreduce.Job;
import java.io.InputStreamReader;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer.Context;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;
import org.apache.hadoop.fs.Path;
import java.io.BufferedReader;
import java.io.IOException;

//Written by Gregory ISLAS
// Defines the Map class for the difference of the two vectors - will just output as key, value the input
public class MapTop10 extends Mapper<LongWritable, Text, DoubleWritable, Text> {
	
	//
	@Override
	protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
		String line[] = value.toString().split("\\s+"); // split the key and the double
		double thekey = -1*Double.parseDouble(line[1]); // key is the page rank score
		String theval = line[0]; // value is the name
		context.write(new DoubleWritable(thekey), new Text(theval)); //write to context - should be two for each key
	}

}
