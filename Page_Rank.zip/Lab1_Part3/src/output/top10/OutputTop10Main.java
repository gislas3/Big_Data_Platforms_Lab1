package output.top10;

import org.apache.hadoop.conf.Configuration;

import org.apache.hadoop.conf.Configured;

import org.apache.hadoop.fs.FileSystem;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;

import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;

import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;

import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

import org.apache.hadoop.util.GenericOptionsParser;

import org.apache.hadoop.util.Tool;

import org.apache.hadoop.util.ToolRunner;

//Written by Gregory ISLAS
public class OutputTop10Main extends Configured implements Tool {

	public int run(String[] args) throws Exception {
		if (args.length != 2) { //simple correct input check
			System.out.println("Usage: [input] [output]");
			System.exit(-1);
		}

		// Creation of the job and titled with a brief description of the task
		Job job = Job.getInstance(getConf());
		job.setJobName("Output Top 10 Page Rank Scores");
		// Set the Mapper, Combiner, and Reducer Classes
		job.setJarByClass(OutputTop10Main.class);
		job.setMapperClass(MapTop10.class);
		job.setReducerClass(ReduceTop10.class); 
		//job.setCombinerClass(ReduceCheckVector.class); //set combiner class to reduce amt of data sent across network

		// set number of reducers
		job.setNumReduceTasks(1); // One Reducer - just want Top 10 output vectors
		job.setMapOutputKeyClass(DoubleWritable.class); // key will be the page rank score of the user
		job.setMapOutputValueClass(Text.class); // value will be the name of the user
		job.setOutputKeyClass(Text.class); // final output key will be the name of the user
		job.setOutputValueClass(DoubleWritable.class); // final output value will be the page rank score

		// Definition of the input and output paths
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		Path outputFilePath = new Path(args[1]);
		// Delete output directory if it exists already
		FileSystem fs = FileSystem.newInstance(getConf());

		if (fs.exists(outputFilePath)) {
			fs.delete(outputFilePath, true);
		}

		return job.waitForCompletion(true) ? 0 : 1; 
	}

	public static void main(String[] args) throws Exception {
		OutputTop10Main cv = new OutputTop10Main(); // initialize the job
		int res = ToolRunner.run(cv, args);
		System.exit(res); // exit with what run method returned
	}

}
