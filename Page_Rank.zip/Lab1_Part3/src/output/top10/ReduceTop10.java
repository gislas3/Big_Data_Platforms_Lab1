package output.top10;

import org.apache.hadoop.mapreduce.Job;  
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Mapper.Context;

import java.io.IOException;
import java.util.LinkedList;

//Written by Gregory ISLAS
// Reduce is simple - just sums up all values for the current column

public class ReduceTop10 extends Reducer<DoubleWritable, Text, Text, DoubleWritable> {
	private int printed = 0; //keep track of number written to the context
	private final static int NUM_TO_PRINT = 10; //number of records to write
    @Override
    protected void reduce(DoubleWritable key, Iterable<Text> values, Context context) throws IOException,InterruptedException
    {	
    	for(Text t: values) {
    		if(printed < NUM_TO_PRINT) {
    			context.write(t, new DoubleWritable(-1*key.get())); //switch the key and values
    		}
    		printed++; //increment the number printed
    	}
    }

  
   }
    




