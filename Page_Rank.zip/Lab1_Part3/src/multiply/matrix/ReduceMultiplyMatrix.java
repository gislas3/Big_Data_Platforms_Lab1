package multiply.matrix;

import org.apache.hadoop.mapreduce.Job;  
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Reducer;
import java.io.IOException;
import java.util.LinkedList;

//Written by Gregory ISLAS
// Reduce is simple - just sums up all values for the current column

public class ReduceMultiplyMatrix extends Reducer<IntWritable, DoubleWritable, IntWritable, DoubleWritable> {
	

    
    @Override
    protected void reduce(IntWritable key, Iterable<DoubleWritable> values, Context context) throws IOException,InterruptedException
    {	
    	double sum = 0.0;
    	for(DoubleWritable d: values) {
    		sum += d.get();
    	} //sum up all values that correspond to the current column
    	context.write(key,  new DoubleWritable(sum));
    }

    }
    




