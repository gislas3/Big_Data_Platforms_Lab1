package multiply.matrix;

import org.apache.hadoop.conf.Configuration;

import org.apache.hadoop.conf.Configured;

import org.apache.hadoop.fs.FileSystem;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;

import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;

import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;

import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

import org.apache.hadoop.util.GenericOptionsParser;

import org.apache.hadoop.util.Tool;

import org.apache.hadoop.util.ToolRunner;

//Written by Gregory ISLAS
public class MultiplyMatrixMain extends Configured implements Tool {

	public int run(String[] args) throws Exception {
		if (args.length != 2) { //simple correct input check
			System.out.println("Usage: [input] [output]");
			System.exit(-1);
		}

		// Creation of the job and titled with a brief description of the task
		Job job = Job.getInstance(getConf());
		job.setJobName("One Round of Matrix Multiplication");
		// Set the Mapper, Combiner, and Reducer Classes
		job.setJarByClass(MultiplyMatrixMain.class);
		job.setMapperClass(MapMultiplyMatrix.class);
		job.setReducerClass(ReduceMultiplyMatrix.class); 
		job.setCombinerClass(ReduceMultiplyMatrix.class); //set combiner class to reduce amt of data sent across network

		// set number of reducers
		job.setNumReduceTasks(5); // Five reducers
		// Definition of the types of the input/output keys
		job.setMapOutputKeyClass(IntWritable.class); // key will be the associated column of the vector
		job.setMapOutputValueClass(DoubleWritable.class); // value will be x[j] * P[i][j]
		job.setOutputKeyClass(IntWritable.class); // final output key will be column of vector
		job.setOutputValueClass(DoubleWritable.class); // final output value will be the result of the matrix multiplication for the specified column of the result vector

		// Definition of the input and output paths
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		Path outputFilePath = new Path(args[1]);
		// Delete output directory if it exists already
		FileSystem fs = FileSystem.newInstance(getConf());

		if (fs.exists(outputFilePath)) {
			fs.delete(outputFilePath, true);
		}

		return job.waitForCompletion(true) ? 0 : 1; 
	}

	public static void main(String[] args) throws Exception {
		MultiplyMatrixMain bm = new MultiplyMatrixMain(); // initialize the job
		int res = ToolRunner.run(bm, args);
		System.exit(res); // exit with what run method returned
	}

}
