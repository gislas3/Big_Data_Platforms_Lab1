package multiply.matrix;

import org.apache.hadoop.mapreduce.Job;
import java.io.InputStreamReader;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer.Context;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;
import org.apache.hadoop.fs.Path;
import java.io.BufferedReader;
import java.io.IOException;

//Written by Gregory ISLAS
// Defines the Map class for the multiplication of the matrix - will output key, value pairs of the form (j, v[j]*P[i][j])
public class MapMultiplyMatrix extends Mapper<LongWritable, Text, IntWritable, DoubleWritable> {
	private static int NUM_NODES; // know number of nodes beforehand
	private double[] vec; //= new double[NUM_NODES]; //used to store the vector in main memory - assumes entire vector will fit in main memory
	private double[] sums; //= new double[NUM_NODES]; // store the sums of the elements of the vector
													// with no corresponding
													// entries in matrix, so
													// send less data over
													// network
	private static final double DAMPING_FACTOR = .85; //universal damping factor
	private double empty_mult;  //used to store the value of alpha/N

	// Read in the vector and store it in main memory
	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		//System.out.println("EMPTY MULT IS " + Double.toString(empty_mult));
		FileSystem fs = FileSystem.get(context.getConfiguration());
		String v = "/page_rank_vector/vector.txt"; // assumes file with vector exists in this directory
		String n = "/num_nodes/num_nodes.txt";
		
		try {

			BufferedReader br = new BufferedReader(new InputStreamReader(fs.open(new Path(n)))); //open the file
			try {
				String line;

				line = br.readLine();

				NUM_NODES = Integer.parseInt(line);
			
			} finally {

				br.close();
			}
		} catch (IOException e) {
			System.out.println(e.toString());
		}
		empty_mult = (1 - DAMPING_FACTOR) / NUM_NODES;
		vec = new double[NUM_NODES];
		sums = new double[NUM_NODES];
		
		try {

			BufferedReader br = new BufferedReader(new InputStreamReader(fs.open(new Path(v)))); //open the file
			try {
				String line;

				line = br.readLine();

				while (line != null) { //read the file, and store each element in the double array defined earlier
					// System.out.println(line);
					String[] linesplit = line.split("\\s+");
					// System.out.println(linesplit[0]);
					int key = Integer.parseInt(linesplit[0]);
					double value = Double.parseDouble(linesplit[1]);
					vec[key] = value;
					line = br.readLine();
				}
			} finally {

				br.close();
			}
		} catch (IOException e) {
			System.out.println(e.toString());
		}
	}

	//
	@Override
	protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException

	{ //definition of the map method
		String[] line = value.toString().split("\\s+"); //split the line on white spaces
		int rowkey = Integer.parseInt(line[0]); // the key - should probably be renamed "colkey"
		int entries = Integer.parseInt(line[1]); // the number of edges in the column
		int index = 2; // the index to start from
		int start = 0; // the id of the first node_to id
		double vec_mult = vec[rowkey]; // the value of the vector to multiply by each element of the current row of the matrix
		double alpha = 1-DAMPING_FACTOR; // used in case multiplying empty entries by alpha or not
		 //non-zero entry row
			while (index < line.length) { // loop through the list of edges
				int curr = Integer.parseInt(line[index]); // current place in the matrix (i.e. the column)
				if (curr != start) { // if skipped empty entries
					for (int i = start; i < curr; i++) { // add up all elements of the vector that correspond to "empty" entries, so dont have to send all across network
						sums[i] += alpha*vec_mult;
					}
				}
				context.write(new IntWritable(curr),
					new DoubleWritable(vec_mult * (DAMPING_FACTOR * ((double)1 / entries) + empty_mult))); //write the value to the context
				start = curr + 1;
				index++;
			}
			if(start == 0) { //no entries, so don't multiply by alpha
				alpha = 1.0;
			}
			for (int i = start; i < NUM_NODES; i++) { //if there exist "empty" entries after last entry in current row of matrix
				sums[i] += alpha*vec_mult;
			}
		
	}

	//cleanup method writes to the context all the row values that correspond to the "empty" entries in the matrix
	@Override
	protected void cleanup(Context context) throws IOException, InterruptedException {
		for (int i = 0; i < sums.length; i++) {

			context.write(new IntWritable(i), new DoubleWritable((double)1/NUM_NODES * sums[i]));
		}
		
	}
}
