package check.vector;

import org.apache.hadoop.conf.Configuration;

import org.apache.hadoop.conf.Configured;

import org.apache.hadoop.fs.FileSystem;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;

import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;

import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;

import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

import org.apache.hadoop.util.GenericOptionsParser;

import org.apache.hadoop.util.Tool;

import org.apache.hadoop.util.ToolRunner;

//Written by Gregory ISLAS
public class CheckVectorMain extends Configured implements Tool {

	public int run(String[] args) throws Exception {
		if (args.length != 2) { //simple correct input check
			System.out.println("Usage: [input] [output]");
			System.exit(-1);
		}

		// Creation of the job and titled with a brief description of the task
		Job job = Job.getInstance(getConf());
		job.setJobName("Track Changes of Vector");
		// Set the Mapper, Combiner, and Reducer Classes
		job.setJarByClass(CheckVectorMain.class);
		job.setMapperClass(MapCheckVector.class);
		job.setReducerClass(ReduceCheckVector.class); 
		//job.setCombinerClass(ReduceCheckVector.class); //set combiner class to reduce amt of data sent across network

		// set number of reducers
		job.setNumReduceTasks(1); // One Reducer - just want average from all vectors 
		// Definition of the types of the input/output keys
		job.setMapOutputKeyClass(IntWritable.class); // key will be the associated column of the vector
		job.setMapOutputValueClass(DoubleWritable.class); // value will be the values of the vector
		job.setOutputKeyClass(IntWritable.class); // final output key will be just a String 
		job.setOutputValueClass(Text.class); // final output value will be the mean absolute difference of the two vectors

		// Definition of the input and output paths
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		Path outputFilePath = new Path(args[1]);
		// Delete output directory if it exists already
		FileSystem fs = FileSystem.newInstance(getConf());

		if (fs.exists(outputFilePath)) {
			fs.delete(outputFilePath, true);
		}

		return job.waitForCompletion(true) ? 0 : 1; 
	}

	public static void main(String[] args) throws Exception {
		CheckVectorMain cv = new CheckVectorMain(); // initialize the job
		int res = ToolRunner.run(cv, args);
		System.exit(res); // exit with what run method returned
	}

}
