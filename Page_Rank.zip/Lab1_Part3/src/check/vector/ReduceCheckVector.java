package check.vector;

import org.apache.hadoop.mapreduce.Job;  
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Mapper.Context;

import java.io.IOException;
import java.util.LinkedList;

//Written by Gregory ISLAS
// Reduce is simple - just sums up all values for the current column

public class ReduceCheckVector extends Reducer<IntWritable, DoubleWritable, IntWritable, Text> {
	private double numerator = 0;
	private int denominator = 0;
    private double sum = 0; //error check - vector should sum up to 1
    @Override
    protected void reduce(IntWritable key, Iterable<DoubleWritable> values, Context context) throws IOException,InterruptedException
    {	
    	double diff = 0;
    	double mult = 1;
    	for(DoubleWritable d: values) {
    		diff += mult*d.get();
    		mult = mult*-1;
    		sum += d.get();
    	} //take absolute difference of the two vectors
    	numerator += Math.abs(diff); //add the diff to the numerator
    	denominator++; //add one to the denominator
    }

    @Override
	protected void cleanup(Context context) throws IOException, InterruptedException {
    	double final_res = numerator/denominator;
    	int towrite = 0;
    	if(Double.compare(final_res, 1e-9) <= 0) { // average abs difference is less than or equal to 1e-5
    		towrite = 1;
    	}
    	System.out.println("Sum is " + Double.toString(sum));
    	System.out.println("Numerator is " + Double.toString(numerator));
    	System.out.println("Denominator is " + denominator);
    	System.out.println("MEAN absolute diff is " + Double.toString(final_res));
    	context.write(new IntWritable(towrite), new Text("")); //write out the result to the context
    }
   }
    




